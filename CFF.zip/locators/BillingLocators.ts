export const BillingLocators = {
  // Sidebar
  billingsNav: "//span[normalize-space()='Billings']",
  addBillingButton: "//*[@id='billings']",

  // Trip Details
  tripDetailsInput: "//*[@id='inputTripDetails']",
  tripDetailsSubmitButton: "//*[@id='billdashBoard']/form/app-trip-details//div[1]//button",

  // Bill Details
  billNumberInput: "//*[@id='inputBillNumber']",
  termDropdown: "//*[@formcontrolname='term']",
  sequenceInput: "//*[@id='inputSequence']",

  // Parties
  shipperInput: "//*[@name='S_input']",
  consigneeInput: "//*[@name='C_input']",
  thirdPartyInput: "//*[@name='T_input']",
  inwardInput: "//*[@name='I_input']",

  //Dimensions and Charges - To be added when test scenarios are finalized
  qtyInput: "//*[@id='inputqty_0']",
  pieceInput: "//*[@formcontrolname='pieces']",
  lengthInput: "//*[@id='inputlength_0']",
  widthInput: "//*[@id='inputweight_0']",
  heightInput: "//*[@id='inputheight_0']",
  weightInput: "//*[@id='inputWeight']",
  scaledweight: "//*[@id='inputscaledweight']",
  calculateButton: "//*[@id='calcButton']"

};
