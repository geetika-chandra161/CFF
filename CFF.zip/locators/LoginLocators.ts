export const LoginLocators = {
  emailField: '[placeholder="Email"]',
  passwordField: '[placeholder="Password"]',
  loginButton: "//div[@role='button' and contains(@class,'dx-button-default')]",
};
