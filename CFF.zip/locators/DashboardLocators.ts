export const DashboardLocators = {
  billingAppTile: "xpath=/html/body/app-root/app-side-nav-outer-toolbar/div/app-dashboard/dx-scroll-view/div/div[1]/div/div[1]/img",
  customerAppTile: "xpath=/html/body/app-root/app-side-nav-outer-toolbar/div/app-dashboard/dx-scroll-view/div/div[1]/div/div[3]/img",
};
