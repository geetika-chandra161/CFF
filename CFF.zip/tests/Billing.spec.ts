import { test, expect, Page } from '@playwright/test';
import { BillingLocators } from '../locators/BillingLocators';
import { DashboardLocators } from '../locators/DashboardLocators';
import { Environment } from '../config/Environment';
import { readBillingData, BillingRow } from '../utils/CsvReader';

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomBillNumber(): string {
  return `${randomInt(100000, 999999)}`;
}

const billingData = readBillingData('test_data/billing_data.csv');

async function openBillingForm(page: Page): Promise<Page> 
{
  await page.goto(Environment.dashboardUrl);
  await page.waitForLoadState('domcontentloaded', { timeout: 90000 });

  await page.locator(DashboardLocators.billingAppTile).click();
  await page.waitForLoadState('domcontentloaded', { timeout: 90000 });
  await page.bringToFront();
  const [newPage] = await Promise.all([page.waitForEvent('popup')]);
  await newPage.waitForLoadState();

  await newPage.locator(BillingLocators.billingsNav).click();
  await newPage.waitForLoadState('domcontentloaded', { timeout: 20000 });

  return newPage;
}

async function fillBillingHeader(newPage: Page, row: BillingRow) 
{
  await newPage.locator(BillingLocators.addBillingButton).click();
  await newPage.waitForLoadState('domcontentloaded', { timeout: 70000 });

  await newPage.locator(BillingLocators.tripDetailsInput).fill(row.tripDetails);
  await newPage.waitForTimeout(4000);
  await newPage.locator(BillingLocators.tripDetailsSubmitButton).click();
  await newPage.waitForLoadState('domcontentloaded', { timeout: 20000 });

  await newPage.locator(BillingLocators.billNumberInput).fill(randomBillNumber());
  await newPage.waitForTimeout(2000);

  await newPage.locator(BillingLocators.termDropdown).click();
  await newPage.waitForTimeout(2000);
  await newPage.selectOption(BillingLocators.termDropdown, { index: Number(row.termIndex) });
  await newPage.waitForTimeout(2000);

  await newPage.locator(BillingLocators.sequenceInput).fill(row.sequence);
  await newPage.waitForTimeout(2000);
}

test.describe('Billing Integration Suite', () => {

  test.skip('TC01 - Shipper ID and Consignee ID population on the fields', async ({ page }) => {
    test.setTimeout(240000);
    const row = billingData[0];
    const newPage = await openBillingForm(page);

    await fillBillingHeader(newPage, row);

    // Enter Shipper and verify it is populated
    await newPage.locator(BillingLocators.shipperInput).fill(row.shipperId);
    await newPage.waitForTimeout(4000);
    await newPage.getByText(row.shipperName).first().click();
    await expect(newPage.locator(BillingLocators.shipperInput)).not.toBeEmpty();

    // Enter Consignee and verify it is populated
    if (row.consigneeId) 
    {
      await newPage.locator(BillingLocators.consigneeInput).fill(row.consigneeId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.consigneeName).first().click();
      await expect(newPage.locator(BillingLocators.consigneeInput)).not.toBeEmpty();
    }
  });

  test.skip('TC02 - Third party populated based on Shipper ID selected and field value is validated', async ({ page }) => {
    test.setTimeout(240000);
    const row = billingData[1];
    const newPage = await openBillingForm(page);

      await fillBillingHeader(newPage, row);

      await newPage.locator(BillingLocators.shipperInput).fill(row.shipperId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.shipperName).first().click();

      // Manually enter third party value and verify it matches expected
      await newPage.locator(BillingLocators.thirdPartyInput).fill(row.thirdPartyExpectedValue);
      await newPage.waitForTimeout(2000);
      await expect(newPage.locator(BillingLocators.thirdPartyInput)).toHaveValue(row.thirdPartyExpectedValue);
    
  });

  test.skip('TC03 - Third party populated based on Shipper ID and Consignee ID selected', async ({ page }) => {
    test.setTimeout(240000);
    const row = billingData[2];
    const newPage = await openBillingForm(page);

      await fillBillingHeader(newPage, row);

      // Select shipper and verify third party auto-populates
      await newPage.locator(BillingLocators.shipperInput).fill(row.shipperId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.shipperName).first().click();
      await newPage.waitForTimeout(2000);

      await expect(newPage.locator(BillingLocators.thirdPartyInput)).toHaveValue(row.thirdPartyExpectedValue);
  });

test.skip('TC04 - Inward field populated based on shipper ID selection', async ({ page }) => {
    test.setTimeout(240000);
    const row = billingData[3];
    const newPage = await openBillingForm(page);

      await fillBillingHeader(newPage, row);

      // Select shipper and verify third party auto-populates
      await newPage.locator(BillingLocators.shipperInput).fill(row.shipperId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.shipperName).first().click();
      await newPage.waitForTimeout(2000);

     await expect(newPage.locator(BillingLocators.inwardInput)).toHaveValue(row.InwardExpectedValue);
     console.log(`Inward field value is: ${await newPage.locator(BillingLocators.inwardInput).inputValue()}`);
  });

test('TC05 - Scaled Weight Accesorial calculation', async ({ page }) => {
    test.setTimeout(240000);
    const row = billingData[4];
    const newPage = await openBillingForm(page);

      await fillBillingHeader(newPage, row);

      // Select shipper and verify third party auto-populates
      await newPage.locator(BillingLocators.shipperInput).fill(row.shipperId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.shipperName).first().click();
      await newPage.waitForTimeout(2000);

      // Enter the Consignee and verify it is populated
      if (row.consigneeId) 
    {
      await newPage.locator(BillingLocators.consigneeInput).fill(row.consigneeId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.consigneeName).first().click();
      await expect(newPage.locator(BillingLocators.consigneeInput)).not.toBeEmpty();
    }
      await newPage.locator(BillingLocators.thirdPartyInput).fill(row.thirdPartyExpectedValue);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.thirdPartyName).first().click();

      // Fill in dimensions and weight
      await newPage.locator(BillingLocators.qtyInput).fill('1');
      await newPage.locator(BillingLocators.pieceInput).fill('1');
      await newPage.locator(BillingLocators.lengthInput).fill('20');
      await newPage.locator(BillingLocators.widthInput).fill('20');
      await newPage.locator(BillingLocators.heightInput).fill('20');
      await newPage.locator(BillingLocators.weightInput).fill('1731');
      await newPage.locator(BillingLocators.scaledweight).fill('2000');
      // Click calculate and verify scaled weight is correct 
      await newPage.locator(BillingLocators.calculateButton).click();
      await newPage.waitForLoadState('load');
      await page.screenshot({ path: 'test_results/TC06_RatedAsAccesorial.png', fullPage: true });

     
  });

  test('TC06 - Rated As Accesorial calculation', async ({ page }) => {
    test.setTimeout(240000);
    const row = billingData[4];
    const newPage = await openBillingForm(page);

      await fillBillingHeader(newPage, row);

      // Select shipper and verify third party auto-populates
      await newPage.locator(BillingLocators.shipperInput).fill(row.shipperId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.shipperName).first().click();
      await newPage.waitForTimeout(2000);

      // Enter the Consignee and verify it is populated
      if (row.consigneeId) 
    {
      await newPage.locator(BillingLocators.consigneeInput).fill(row.consigneeId);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.consigneeName).first().click();
      await expect(newPage.locator(BillingLocators.consigneeInput)).not.toBeEmpty();
    }
      await newPage.locator(BillingLocators.thirdPartyInput).fill(row.thirdPartyExpectedValue);
      await newPage.waitForTimeout(4000);
      await newPage.getByText(row.thirdPartyName).first().click();

      // Fill in dimensions and weight
      await newPage.locator(BillingLocators.qtyInput).fill('1');
      await newPage.locator(BillingLocators.pieceInput).fill('1');
      await newPage.locator(BillingLocators.lengthInput).fill('27');
      await newPage.locator(BillingLocators.widthInput).fill('300');
      await newPage.locator(BillingLocators.heightInput).fill('20');
      await newPage.locator(BillingLocators.weightInput).fill('100');

      // Click calculate and verify scaled weight is correct 
      await newPage.locator(BillingLocators.calculateButton).click();
      await newPage.waitForLoadState('load');
      await page.screenshot({ path: 'test_results/TC06_RatedAsAccesorial.png', fullPage: true });

     
  });


});
