import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { Environment } from '../config/Environment';

test.beforeAll('Login to CFF - Stable', async ({ browser }) => {
  test.setTimeout(90000);

  const context = await browser.newContext();
  const page = await context.newPage();

  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(Environment.credentials.email, Environment.credentials.password);
  await loginPage.saveSession(context, Environment.storageStatePath);

  await context.close();
});
