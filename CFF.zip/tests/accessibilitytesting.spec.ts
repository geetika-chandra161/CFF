import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.skip('Accessibility scan of homepage', async ({ page }) => {

  await page.goto('https://google.com');

  const accessibilityScanResults = await new AxeBuilder({ page }).analyze();

   expect(accessibilityScanResults.violations).toEqual([]);

  await page.keyboard.press('Tab');

  //await expect(page.locator(':focus')).toBeVisible();

  

  await page.keyboard.press('Enter');
});