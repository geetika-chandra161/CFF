type EnvName = 'uat' | 'dev' | 'prod';

const ENV: EnvName = 'dev';

const baseUrls: Record<EnvName, string> = {
  uat:   'https://atm.fastfrate.com/auth-uat/',
  dev:  'https://atm.fastfrate.com/auth-dev/',
  prod: 'https://atm.fastfrate.com/',
};

const baseUrl = baseUrls[ENV];

export class Environment {
  static readonly env = ENV;
  static readonly baseUrl = baseUrl;
  static readonly dashboardUrl = `${baseUrl}dashboard`;

  static readonly credentials = {
    email: 'geetika.chandra@atomicnorth.com',
    password: 'Qwerty@123456',
  };

  static readonly storageStatePath = 'test_data/loginStorageState.json';
}
