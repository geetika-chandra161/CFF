import { Page, BrowserContext, expect } from '@playwright/test';
import { LoginLocators } from '../locators/LoginLocators';
import { Environment } from '../config/Environment';

export class LoginPage {
  private page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.goto(Environment.baseUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
  }

  async login(email: string, password: string) {
    const emailField = this.page.locator(LoginLocators.emailField);
    await expect(emailField).toBeVisible({ timeout: 90000 });
    await emailField.fill(email);
    await this.page.locator(LoginLocators.passwordField).fill(password);
    await this.page.locator(LoginLocators.loginButton).click();
    await this.page.waitForURL(Environment.dashboardUrl, { timeout: 30000 });
  }

  async saveSession(context: BrowserContext, path: string) {
    await context.storageState({ path });
  }
}
