import * as fs from 'fs';
import * as path from 'path';
import { parse } from 'csv-parse/sync';

export interface BillingRow {
  tripDetails: string;
  sequence: string;
  termIndex: string;
  shipperId: string;
  shipperName: string;
  consigneeId: string;
  consigneeName: string;
  thirdPartyExpectedValue: string;
  thirdPartyName: string;
  inwardExpectedValue: string;
}

export function readBillingData(filePath: string): BillingRow[] {
  const content = fs.readFileSync(path.resolve(filePath), 'utf-8');
  return parse(content, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  }) as BillingRow[];
}
