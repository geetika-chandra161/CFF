# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e5]:
    - toolbar [ref=e6]:
      - generic [ref=e7]:
        - generic [ref=e10]: Auth App
        - img "Menu" [ref=e15] [cursor=pointer]
        - group [ref=e21]:
          - button "dropdownbutton" [ref=e23] [cursor=pointer]
        - text: 
  - generic [ref=e28]:
    - generic [ref=e30] [cursor=pointer]:
      - img "icon" [ref=e32]
      - generic [ref=e34]: Billing
    - generic [ref=e36] [cursor=pointer]:
      - img "icon" [ref=e38]
      - generic [ref=e40]: Pricing
    - generic [ref=e42] [cursor=pointer]:
      - img "icon" [ref=e44]
      - generic [ref=e46]: Customer
    - generic [ref=e48] [cursor=pointer]:
      - img "icon" [ref=e50]
      - generic [ref=e52]: Contract
    - generic [ref=e54] [cursor=pointer]:
      - img "icon" [ref=e56]
      - generic [ref=e58]: Tax
```